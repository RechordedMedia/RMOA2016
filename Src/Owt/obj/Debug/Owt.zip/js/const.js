// ====================== GLOBAL VARIABLES (VALUES)
//dev value 
app.value('baseUrl', 'https://randomuser.me/api/');

//live value
//amrodApp.value( 'baseUrl', 'http://app.afriforum.co.za/Api/MSPApi' );





app.value('http_defaults', { timeout: 15000 }); //15 seconds
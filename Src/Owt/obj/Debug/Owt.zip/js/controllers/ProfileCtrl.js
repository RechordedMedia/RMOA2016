app.controller('ProfileCtrl', function ($scope, $stateParams) {

});
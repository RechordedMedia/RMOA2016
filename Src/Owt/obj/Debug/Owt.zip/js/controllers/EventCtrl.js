app.controller('EventCtrl', function ($scope, $stateParams) {

});
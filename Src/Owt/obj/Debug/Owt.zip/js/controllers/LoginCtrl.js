app.controller('LoginCtrl', function ($scope, $stateParams) {
    
});
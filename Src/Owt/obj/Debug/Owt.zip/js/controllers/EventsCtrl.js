app.controller('EventsCtrl', function ($scope, $stateParams) {

});